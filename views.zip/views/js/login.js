
function capturar(){
  var respuesta=document.getElementById('respuesta');
  var user=document.getElementById('username').value;
  var pass=document.getElementById('password').value;
  var obj = JSON.stringify({ 'username':user , 'password': pass })
  var request = new XMLHttpRequest()
  request.withCredentials = true
  request.open('POST', ' http://127.0.0.1:5000/login', true)
  request.setRequestHeader("Content-Type", "application/json");
  request.onload = function(response) {
    

    var data = JSON.parse(this.response)
    if(request.status==201){
      
      console.log(data["access_token"])
      window.location.href="anuncios.html"
      
    }else{
      function returntToPreviousPage(){
        window.history.back("index.html");
      }
      respuesta.innerHTML =`<div class="alert alert-danger" role="alert">`+ data["msg"] +` </div>`;  
      console.log(data["msg"]);
       
    }

    console.log(request.status) 
    
  }
  request.send(obj)
  
/*Bearer+' '+data["access_token"]*/
}